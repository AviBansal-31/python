Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> a = [1,2,5,10,225,3]
>>> b = sum(a)
>>> print b
246
>>> y = b/len(a)
>>> print y
41
>>> 
